package org.sel.client;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.sel.client.entity.Doc;
import org.sel.client.entity.Product;
import org.sel.client.json.LogHandler;

import java.io.FileInputStream;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Timer;
import java.util.concurrent.*;
import java.util.logging.ConsoleHandler;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.Logger;

final public class ApiClient {
    private final TimeUnit timeUnit;
    private final int requestLimit;
    private final URI uri;
    private final HttpClient httpClient;
    //ApiClient object is used to control throughput.
    private static ApiClient instance;
    final private Logger logger;

    private int requestCount;
    private long releaseTime;

    private ApiClient(TimeUnit timeUnit, int requestLimit, URI uri, HttpClient httpClient) {
        this.timeUnit = timeUnit;
        this.requestLimit = requestLimit;
        this.uri = uri;
        this.httpClient = httpClient;
        this.logger = Logger.getAnonymousLogger();
        //logger.addHandler(new ConsoleHandler());
    }
    public static  synchronized ApiClient getInstance() throws IOException {
        if(instance == null){
            String rootPath = Thread.currentThread().getContextClassLoader().getResource("").getPath();
            String propPath = rootPath + "ApiClient.prop";
            Properties properties = new Properties();
            properties.load(new FileInputStream(propPath));
            instance = new ApiClient(
                    TimeUnit.valueOf(properties.getProperty("TimeUnit", "SECOND")),
                    Integer.parseInt(properties.getProperty("RequestLimit", "2")),
                    URI.create(properties.getProperty("URI", "https://markirovka.demo.crpt.tech/")),
                    buildHttpClient(properties));
        }
        return instance;
    }
    private static HttpClient buildHttpClient(Properties properties){
        //Include more options if required
        return HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(Long.parseLong(properties.getProperty("TimeOut", "20"))))
                .followRedirects(HttpClient.Redirect.valueOf(properties.getProperty("Redirect", "NEVER")))
                .version(HttpClient.Version.valueOf(properties.getProperty("HttpVersion", "HTTP_2")))
                .build();
    }

    public CompletableFuture<HttpResponse<byte[]>> sendRFDoc(String doc, String ucds) throws IOException, InterruptedException {
        //For future customization
        HttpRequest httpRequest = HttpRequest.newBuilder(this.uri).header("accept", "*/*").method("POST", HttpRequest.BodyPublishers.ofString(doc)).build();
        CompletableFuture<HttpResponse<byte[]>> completableFuture = null;
        synchronized (this) {
            if(requestLimit > 0) {
                if(requestCount == 0) {
                    requestCount++;
                    releaseTime = System.currentTimeMillis() + timeUnit.toMillis(1);
                }
                while(requestCount > requestLimit && releaseTime > System.currentTimeMillis()){
                    long sleepTime = System.currentTimeMillis() - releaseTime;
                    if(sleepTime > 0) this.wait(sleepTime);
                }
                if(requestCount > requestLimit) {
                    requestCount = 1;
                    releaseTime = System.currentTimeMillis() + timeUnit.toMillis(1);
                    this.notifyAll();
                }
                requestCount++;
            }
        }
        completableFuture = httpClient.sendAsync(httpRequest, HttpResponse.BodyHandlers.ofByteArray());
        logger.log(Level.INFO, "Requested: " + LocalTime.now().toString() + ", "
                + LocalTime.ofInstant(Instant.ofEpochMilli(releaseTime), ZoneId.systemDefault()) + ", "
                + requestCount);
        return completableFuture;
    }
    public enum MarshallType {
        JSON,
        CSV,
        XML
    }
    public String marshallDoc(MarshallType marshallType, Doc doc) throws JsonProcessingException {
        switch (marshallType){
            case JSON -> {
                ObjectMapper objectMapper = new ObjectMapper();
                return objectMapper.writeValueAsString(doc);
            }
            case CSV -> {
                //TODO
                //CSV document
                return null;
            }
            case XML -> {
                //TODO
                //XML document
                return null;
            }
            default -> {
                return null;
            }
        }
    }

}
